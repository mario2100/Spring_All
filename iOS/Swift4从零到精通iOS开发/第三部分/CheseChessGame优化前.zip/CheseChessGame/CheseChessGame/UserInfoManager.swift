//
//  UserInfoManager.swift
//  CheseChessGame
//
//  Created by vip on 16/11/17.
//  Copyright © 2016年 jaki. All rights reserved.
//

import UIKit

class UserInfoManager: NSObject {
    class func saveAudioState(isOn:Bool){
        if isOn {
            UserDefaults.standard.set("on", forKey: "playerKey")
        }else{
            UserDefaults.standard.set("off", forKey: "playerKey")
        }
        UserDefaults.standard.synchronize()
    }
    
    class func getAudioState()->Bool{
        let on = UserDefaults.standard.string(forKey: "playerKey")
        if let o = on {
            if o == "on" {
                return true
            }else{
                return false
            }
        }else{
            return true
        }
    }
}
