//
//  ViewController.swift
//  CheseChessGame
//
//  Created by vip on 16/11/17.
//  Copyright © 2016年 jaki. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var startGameButton: UIButton!
    
    @IBOutlet weak var audioButton: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        if  UserInfoManager.getAudioState() {
            audioButton.setTitle("音效:开", for: .normal)
            MusicEngine.sharedInstance.playBackgroudMusic()
            
        }else{
            MusicEngine.sharedInstance.stopBackgroudMusic()
            audioButton.setTitle("音效:关", for: .normal)
        }
    }

    @IBAction func startGame(_ sender: UIButton) {
        let gameViewController = GameViewController()
        self.present(gameViewController, animated: true, completion: nil)
    }
    
    @IBAction func setMusic(_ sender: UIButton) {
        if UserInfoManager.getAudioState() {
            sender.setTitle("音效:关", for: .normal)
            UserInfoManager.saveAudioState(isOn: false)
            MusicEngine.sharedInstance.stopBackgroudMusic()
        }else{
            sender.setTitle("音效:开", for: .normal)
            UserInfoManager.saveAudioState(isOn: true)
            MusicEngine.sharedInstance.playBackgroudMusic()
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

