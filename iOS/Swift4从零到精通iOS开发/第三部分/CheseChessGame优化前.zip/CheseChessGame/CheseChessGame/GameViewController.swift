//
//  GameViewController.swift
//  CheseChessGame
//
//  Created by vip on 16/11/17.
//  Copyright © 2016年 jaki. All rights reserved.
//

import UIKit

class GameViewController: UIViewController,GameEngineDelegate {

    var board:ChessBoard?
    var gameEngine:GameEngine?
    
    var startButton:UIButton?
    var settingButton:UIButton?
    var tipLabel:UILabel?
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor.white
        // Do any additional setup after loading the view.
        let imageView = UIImageView(frame: self.view.frame)
        imageView.image = UIImage(named: "gameBg")
        self.view.addSubview(imageView)
        board = ChessBoard(origin: CGPoint(x: 20, y: 80))
        self.view.addSubview(board!)
        gameEngine = GameEngine(board: board!, isRed: true)
        gameEngine!.delegate = self
        installUI()
    }
    
    func installUI()  {
        startButton = UIButton(type: .system)
        startButton?.frame = CGRect(x: 40, y: self.view.frame.size.height-80, width: self.view.frame.size.width/2-80, height: 30)
        startButton?.setTitle("开始游戏", for: .normal)
        startButton?.backgroundColor = UIColor.green
        startButton?.setTitleColor(UIColor.red, for: .normal)
        startButton?.addTarget(self, action: #selector(startGame), for: .touchUpInside)
        self.view.addSubview(startButton!)
        
        settingButton = UIButton(type: .system)
        settingButton?.frame = CGRect(x: self.view.frame.size.width/2+40, y: self.view.frame.size.height-80, width: self.view.frame.size.width/2-80, height: 30)
        settingButton?.setTitle("红方行棋", for: .normal)
        settingButton?.setTitleColor(UIColor.red, for: .normal)
        settingButton?.backgroundColor = UIColor.green
        settingButton?.addTarget(self, action: #selector(setting), for: .touchUpInside)
        self.view.addSubview(settingButton!)
        
        tipLabel = UILabel(frame: CGRect(x: self.view.frame.size.width/2-100, y: 180, width: 200, height: 40))
        tipLabel?.font = UIFont.systemFont(ofSize: 30)
        tipLabel?.backgroundColor = UIColor.clear
        tipLabel?.textAlignment = .center
        tipLabel?.isHidden = true
        self.view.addSubview(tipLabel!)
    }
    
    func startGame(btn:UIButton){
        tipLabel?.isHidden = true
        gameEngine?.startGame()
        settingButton?.backgroundColor = UIColor.gray
        btn.setTitle("重新开始", for: .normal)
        settingButton?.isEnabled = false
    }
    
    func setting(btn:UIButton){
        if btn.title(for: .normal)=="红方行棋" {
            btn.setTitle("绿方行棋", for: .normal)
            gameEngine?.setRedFirstMove(red: false)
        }else{
            btn.setTitle("红方行棋", for: .normal)
            gameEngine?.setRedFirstMove(red: true)
        }
    }
    
    func gameOver(redWin:Bool){
        settingButton?.backgroundColor = UIColor.green
        settingButton?.isEnabled = true
        if redWin {
            tipLabel?.text = "红方胜"
            tipLabel?.textColor = UIColor.red
        }else{
            tipLabel?.text = "绿方胜"
            tipLabel?.textColor = UIColor.green
        }
        tipLabel?.isHidden = false
    }
    
    func couldMoveChange(red: Bool) {
        if red {
            settingButton?.setTitle("红方行棋", for: .normal)
        }else{
             settingButton?.setTitle("绿方行棋", for: .normal)
        }
    }
    
    func itemClick(item:ChessItem)  {
        item.changeSelectedStateItem()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
