//
//  ChessItem.swift
//  CheseChessGame
//
//  Created by vip on 16/11/17.
//  Copyright © 2016年 jaki. All rights reserved.
//

import UIKit

class ChessItem: UIButton {
    let itemWidth = (UIScreen.main.bounds.size.width-40)/9-4
    var itemState = false
    var isRed:Bool?
    init(center:CGPoint) {
        super.init(frame: CGRect(origin: CGPoint(x: center.x-itemWidth/2, y: center.y-itemWidth/2), size: CGSize(width: itemWidth, height: itemWidth)))
        installUI()
    }
    
    
    func installUI(){
        self.layer.masksToBounds = true
        self.layer.cornerRadius = itemWidth/2
        self.layer.borderWidth = 0.5
        self.backgroundColor = UIColor.white
    }
    
    func setTitle(title:String,isRed:Bool){
        self.setTitle(title, for: .normal)
        if isRed {
            self.setTitleColor(UIColor.red, for: .normal)
            self.layer.borderColor = UIColor.red.cgColor
            self.isRed = true
        }else{
            self.setTitleColor(UIColor.green, for: .normal)
            self.layer.borderColor = UIColor.green.cgColor
            self.transform = CGAffineTransform(rotationAngle: CGFloat(M_PI))
            self.isRed = false
        }
    }
    
    func changeSelectedStateItem()  {
        if !itemState {
            itemState = true
            self.backgroundColor = UIColor.purple
        }else{
            itemState = false
            self.backgroundColor = UIColor.white
        }
    }
    
    func setSelectedState()  {
        if !itemState {
            itemState = true
            self.backgroundColor = UIColor.purple
        }
    }
    func setUnselectedState()  {
        if itemState {
            itemState = false
            self.backgroundColor = UIColor.white
        }
    }

    
    
    
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

}
