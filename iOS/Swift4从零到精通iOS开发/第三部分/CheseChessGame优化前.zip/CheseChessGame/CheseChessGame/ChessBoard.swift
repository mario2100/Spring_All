//
//  ChessBoard.swift
//  CheseChessGame
//
//  Created by vip on 16/11/19.
//  Copyright © 2016年 jaki. All rights reserved.
//

import UIKit

protocol ChessBoardDelegate {
    func itemClick(item:ChessItem)
    func itemMoveEnd()
    func gameOver(redWin:Bool)
}


class ChessBoard: UIView {

    
    let Width = (UIScreen.main.bounds.width-40)/9
    let BoardWidth = (UIScreen.main.bounds.width-40)
    let BoardHeight = (UIScreen.main.bounds.width-40)/9*10
    let redChessItemTitle = ["車","馬","相","士","帥","士","相","馬","車","炮","炮","兵","兵","兵","兵","兵"]
    let greenChessItemTitle = ["车","马","象","仕","将","仕","象","马","车","炮","炮","卒","卒","卒","卒","卒"]
    var currentRedItem = Array<ChessItem>()
    var currentGreenItem = Array<ChessItem>()
    
    var currentWantMovePositions:[(Int,Int)] = []
    var delegate:ChessBoardDelegate?
    var tipButtonsArray:[TipButton] = Array<TipButton>()
    
    init(origin:CGPoint) {
        super.init(frame: CGRect(origin: origin, size: CGSize(width: Width*9, height: Width*10)))
        self.backgroundColor = UIColor(red: 1, green: 253/255.0, blue: 234/255.0, alpha: 1)
        let label1 = UILabel(frame: CGRect(x: Width, y: Width/2+Width*4, width: Width*3, height: Width))
        label1.backgroundColor = UIColor.clear
        label1.text = "楚河"
        label1.textAlignment = .center
        self.addSubview(label1)
        
        let label2 = UILabel(frame: CGRect(x: BoardWidth-Width-Width*3, y: Width/2+Width*4, width: Width*3, height: Width))
        label2.textAlignment = .center
        label2.backgroundColor = UIColor.clear
        label2.text = "漢界"
        label2.transform = CGAffineTransform(rotationAngle: CGFloat(M_PI))
        self.addSubview(label2)
        reStartGame()
    }
    
    func reStartGame()  {
        tipButtonsArray.forEach { (btn) in
            btn.removeFromSuperview()
        }
        currentRedItem.forEach { (item) in
            item.removeFromSuperview()
        }
        currentGreenItem.forEach { (item) in
            item.removeFromSuperview()
        }
        currentRedItem.removeAll()
        currentGreenItem.removeAll()
        tipButtonsArray.removeAll()
        for index in 0..<16 {
            var redItem:ChessItem?
            var greenItem:ChessItem?
            if index<9 {
                redItem = ChessItem(center: CGPoint(x: Width/2+CGFloat(index)*Width, y: BoardHeight-Width/2))
                redItem?.setTitle(title: redChessItemTitle[index], isRed: true)
                greenItem = ChessItem(center: CGPoint(x: Width/2+CGFloat(index)*Width, y: Width/2))
                greenItem?.setTitle(title: greenChessItemTitle[index], isRed: false)
            }else if(index==9){
                redItem = ChessItem(center: CGPoint(x: Width/2+Width, y: BoardHeight-Width/2-Width*2))
                redItem?.setTitle(title: redChessItemTitle[index], isRed: true)
                greenItem = ChessItem(center: CGPoint(x: Width/2+Width, y: Width/2+Width*2))
                greenItem?.setTitle(title: greenChessItemTitle[index], isRed: false)

            }else if(index==10){
                redItem = ChessItem(center: CGPoint(x:BoardWidth-Width/2-Width, y: BoardHeight-Width/2-Width*2))
                redItem?.setTitle(title: redChessItemTitle[index], isRed: true)
                greenItem = ChessItem(center: CGPoint(x: BoardWidth-Width/2-Width, y: Width/2+Width*2))
                greenItem?.setTitle(title: greenChessItemTitle[index], isRed: false)

            }else{
                redItem = ChessItem(center: CGPoint(x:Width/2+CGFloat(index-11)*2*Width, y: BoardHeight-Width/2-Width*3))
                redItem?.setTitle(title: redChessItemTitle[index], isRed: true)
                greenItem = ChessItem(center: CGPoint(x: Width/2+CGFloat(index-11)*2*Width, y: Width/2+Width*3))
                greenItem?.setTitle(title: greenChessItemTitle[index], isRed: false)
            }
            redItem?.addTarget(self, action: #selector(itemClick), for: .touchUpInside)
            greenItem?.addTarget(self, action: #selector(itemClick), for: .touchUpInside)
            self.addSubview(redItem!)
            self.addSubview(greenItem!)
            currentRedItem.append(redItem!)
            currentGreenItem.append(greenItem!)
        }
    }
    
    func itemClick(item:ChessItem) {
        if delegate != nil {
            delegate?.itemClick(item: item)
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        let context = UIGraphicsGetCurrentContext()
        context?.setStrokeColor(UIColor.black.cgColor)
        context?.setLineWidth(0.5)
        //画水平线
        for index in 0..<10 {
            context?.move(to: CGPoint(x: Width/2, y: Width/2+CGFloat(index)*Width))
            context?.addLine(to: CGPoint(x: BoardWidth-Width/2, y: Width/2+CGFloat(index)*Width))
        }
        for index in 0..<9 {
            if index==0 || index == 8 {
                context?.move(to: CGPoint(x: Width/2+CGFloat(index)*Width, y: Width/2))
                context?.addLine(to: CGPoint(x:  Width/2+CGFloat(index)*Width, y: BoardHeight-Width/2))
            }else{
                context?.move(to: CGPoint(x: Width/2+CGFloat(index)*Width, y: Width/2))
                context?.addLine(to: CGPoint(x:  Width/2+CGFloat(index)*Width, y: BoardHeight-Width/2-Width*5))
                context?.move(to: CGPoint(x: Width/2+CGFloat(index)*Width, y: BoardHeight-Width/2-Width*4))
                context?.addLine(to: CGPoint(x: Width/2+CGFloat(index)*Width, y: BoardHeight-Width/2))
            }
        }
        context?.move(to: CGPoint(x: Width/2+Width*3, y: Width/2))
        context?.addLine(to: CGPoint(x: Width/2+Width*5, y:  Width/2+Width*2))
        context?.move(to: CGPoint(x: Width/2+Width*5, y: Width/2))
        context?.addLine(to: CGPoint(x: Width/2+Width*3, y:  Width/2+Width*2))
        
        context?.move(to: CGPoint(x: Width/2+Width*3, y:BoardHeight-Width/2))
        context?.addLine(to: CGPoint(x: Width/2+Width*5, y: BoardHeight-Width/2-Width*2))
        context?.move(to: CGPoint(x: Width/2+Width*5, y:BoardHeight-Width/2))
        context?.addLine(to: CGPoint(x: Width/2+Width*3, y: BoardHeight-Width/2-Width*2))
        context?.drawPath(using: .stroke)
        
        
    }
    
    
    func cancelAllSeleted()  {
        currentRedItem.forEach { (item) in
            item.setUnselectedState()
        }
        currentGreenItem.forEach { (item) in
            item.setUnselectedState()
        }
    }

    func transformPointToPosition(item:ChessItem)->(Int,Int){
        return (Int(item.center.x-Width/2)/Int(Width),Int(item.center.y-Width/2)/Int(Width))
    }
    
    func getAllRedPositons()->[(Int,Int)]  {
        var postitions:[(Int,Int)] = []
        currentRedItem.forEach { (item) in
            postitions.append(transformPointToPosition(item: item))
        }
        return postitions
    }
    
    func getAllGreenPositons()->[(Int,Int)]  {
        var postitions:[(Int,Int)] = []
        currentGreenItem.forEach { (item) in
            postitions.append(transformPointToPosition(item: item))
        }
        return postitions
    }
    
    
    func wantMove(positions:[(Int,Int)],item:ChessItem) {
        var resultPositions:[(Int,Int)] = []
        
        if item.isRed! {
            let redList = getAllRedPositons()
            positions.forEach({ (position) in
                if redList.contains(where: { (pos) -> Bool in
                    return pos == position
                }){
                   //此位置移除掉
                }else{
                    resultPositions.append(position)
                }
            })
        }else{
            let greenList = getAllGreenPositons()
            positions.forEach({ (position) in
                if greenList.contains(where: { (pos) -> Bool in
                    return pos == position
                }){
                    //此位置移除掉
                }else{
                    resultPositions.append(position)
                }
            })
        }
        currentWantMovePositions = resultPositions
        creatTipItem(positions: resultPositions)
        
    }
    
    func creatTipItem(positions:[(Int,Int)]) {
        tipButtonsArray.forEach { (button) in
            button.removeFromSuperview()
        }
        tipButtonsArray.removeAll()
        for index in 0..<positions.count {
            let tip = TipButton(center: CGPoint(x: Width/2+Width*CGFloat(positions[index].0), y: Width/2+Width*CGFloat(positions[index].1)))
            self.addSubview(tip)
            tipButtonsArray.append(tip)
            tip.tag = 100+index
            tip.addTarget(self, action: #selector(moveToTip), for: .touchUpInside)
        }
    }
    
    func moveToTip(tipButton:TipButton)  {
        let position = currentWantMovePositions[tipButton.tag-100]
        var item:ChessItem?
        currentRedItem.forEach { (it) in
            if it.itemState {
                item = it
            }
        }
        currentGreenItem.forEach { (it) in
            if  it.itemState {
                item = it
            }
        }
        //进行吃子操作
        var list:[(Int,Int)] = []
        if item!.isRed! {
            list = getAllGreenPositons()
        }else{
            list = getAllRedPositons()
        }
        if list.contains(where: { (pos) -> Bool in
            return pos == position
        }) {
            var removeItem:ChessItem?
            if item!.isRed! {
                currentGreenItem.forEach({ (it) in
                    if transformPointToPosition(item: it) == position{
                    removeItem = it
                    }
                })
            }else{
                currentRedItem.forEach({ (it) in
                    if transformPointToPosition(item: it) == position{
                       removeItem = it
                    }
                })
            }
            if let re = removeItem {
                if re.isRed! {
                    currentRedItem.remove(at: currentRedItem.index(of: re)!)
                }else{
                    currentGreenItem.remove(at: currentGreenItem.index(of: re)!)
                }
                re.removeFromSuperview()
                if re.title(for: .normal) == "将" {
                    if delegate != nil {
                        delegate?.gameOver(redWin: true)
                    }
                }
                if re.title(for: .normal) == "帥" {
                    if delegate != nil {
                        delegate?.gameOver(redWin: false)
                    }
                }
            }
        }
        UIView.animate(withDuration: 0.3, animations: {() -> Void in
            item?.center = CGPoint(x: self.Width/2+self.Width*CGFloat(position.0), y: self.Width/2+self.Width*CGFloat(position.1))
        })
        tipButtonsArray.forEach { (button) in
            button.removeFromSuperview()
        }
        tipButtonsArray.removeAll()
        cancelAllSeleted()
        if delegate != nil {
            delegate?.itemMoveEnd()
        }
    }
}
