//
//  GameEngine.swift
//  CheseChessGame
//
//  Created by vip on 16/11/20.
//  Copyright © 2016年 jaki. All rights reserved.
//

import UIKit

protocol GameEngineDelegate {
    func gameOver(redWin:Bool)
    func couldMoveChange(red:Bool)
}

class GameEngine: NSObject,ChessBoardDelegate {
    var gameBoard:ChessBoard?
    var isRedFirst = true
    var currentShouldRedMovde = true
    
    
    var isStarting = false
    var delegate:GameEngineDelegate?
    
    init(board:ChessBoard,isRed:Bool) {
        super.init()
        isRedFirst = isRed
        currentShouldRedMovde = isRed
        gameBoard = board
        gameBoard?.delegate = self
    }
    
    func setRedFirstMove(red:Bool){
        isRedFirst = red
        currentShouldRedMovde = red
    }
    
    func startGame(){
        gameBoard!.reStartGame()
        isStarting = true
    }
    
    func itemClick(item: ChessItem) {
        if !isStarting {
            return
        }
        if item.isRed! {
            if currentShouldRedMovde {
                gameBoard?.cancelAllSeleted()
                item.changeSelectedStateItem()
                checkItemShouldMove(item: item)
            }
        }else{
            if !currentShouldRedMovde {
                gameBoard?.cancelAllSeleted()
                item.changeSelectedStateItem()
                checkItemShouldMove(item: item)
            }
        }
    }
    
    func checkItemShouldMove(item:ChessItem){
        let position = gameBoard!.transformPointToPosition(item: item)
        let redList = gameBoard!.getAllRedPositons()
        let greenList = gameBoard!.getAllGreenPositons()
        var couldMovePositon:[(Int,Int)] = []
        if item.title(for: .normal) == "兵" {
            if position.1 > 4{
                couldMovePositon = [(position.0,position.1-1)]
            }else{
                //左右前
                if position.0>0 {
                    couldMovePositon.append((position.0-1,position.1))
                }
                if position.0<8 {
                    couldMovePositon.append((position.0+1,position.1))
                }
                if position.1>0 {
                    couldMovePositon.append((position.0,position.1-1))
                }
            }
            
        }
        if item.title(for: .normal) == "卒" {
            if position.1 < 5{
                couldMovePositon = [(position.0,position.1+1)]
            }else{
                //左右前
                if position.0>0 {
                    couldMovePositon.append((position.0-1,position.1))
                }
                if position.0<8 {
                    couldMovePositon.append((position.0+1,position.1))
                }
                if position.1<9 {
                    couldMovePositon.append((position.0,position.1+1))
                }
            }
        }
        if item.title(for: .normal) == "士" {
            if position.0<5 && position.1>7 {
                couldMovePositon.append((position.0+1,position.1-1))
            }
            if position.0>3 && position.1>7 {
                couldMovePositon.append((position.0-1,position.1-1))
            }
            if position.0>3 && position.1<9 {
                couldMovePositon.append((position.0-1,position.1+1))
            }
            if position.0<5 && position.1<9 {
                couldMovePositon.append((position.0+1,position.1+1))
            }
        }
        if item.title(for: .normal) == "仕" {
            if position.0<5 && position.1<2 {
                couldMovePositon.append((position.0+1,position.1+1))
            }
            if position.0>3 && position.1<2 {
                couldMovePositon.append((position.0-1,position.1+1))
            }
            if position.0>3 && position.1>0 {
                couldMovePositon.append((position.0-1,position.1-1))
            }
            if position.0<5 && position.1>0 {
                couldMovePositon.append((position.0+1,position.1-1))
            }
        }
        if item.title(for: .normal) == "将" {
            if position.0<5 {
                couldMovePositon.append((position.0+1,position.1))
            }
            if position.0>3{
                couldMovePositon.append((position.0-1,position.1))
            }
            if position.1>0 {
                couldMovePositon.append((position.0,position.1-1))
            }
            if position.1<2 {
                couldMovePositon.append((position.0,position.1+1))
            }
        }
        if item.title(for: .normal) == "帥" {
            if position.0<5 {
                couldMovePositon.append((position.0+1,position.1))
            }
            if position.0>3{
                couldMovePositon.append((position.0-1,position.1))
            }
            if position.1>7 {
                couldMovePositon.append((position.0,position.1-1))
            }
            if position.1<9 {
                couldMovePositon.append((position.0,position.1+1))
            }
        }
        if item.title(for: .normal) == "相" {
            if position.0-2>=0 && position.1-2>=5 {
                if (redList.contains(where: { (pos) -> Bool in
                    return pos == (position.0-1,position.1-1)
                }) || (greenList.contains(where: { (pos) -> Bool in
                    return pos == (position.0-1,position.1-1)
                }))) {
                    //不添加此位置
                }else{
                    couldMovePositon.append((position.0-2,position.1-2))
                }
            }
            if position.0-2>=0 && position.1+2<=9 {
                if (redList.contains(where: { (pos) -> Bool in
                    return pos == (position.0-1,position.1+1)
                }) || (greenList.contains(where: { (pos) -> Bool in
                    return pos == (position.0-1,position.1+1)
                }))) {
                    //不添加此位置
                }else{
                    couldMovePositon.append((position.0-2,position.1+2))
                }
            }
            if position.0+2<=8 && position.1-2>=5 {
                if (redList.contains(where: { (pos) -> Bool in
                    return pos == (position.0+1,position.1-1)
                }) || (greenList.contains(where: { (pos) -> Bool in
                    return pos == (position.0+1,position.1-1)
                }))) {
                    //不添加此位置
                }else{
                    couldMovePositon.append((position.0+2,position.1-2))
                }
            }
            if position.0+2<=8 && position.1+2<=9 {
                if (redList.contains(where: { (pos) -> Bool in
                    return pos == (position.0+1,position.1+1)
                }) || (greenList.contains(where: { (pos) -> Bool in
                    return pos == (position.0+1,position.1+1)
                }))) {
                    //不添加此位置
                }else{
                    couldMovePositon.append((position.0+2,position.1+2))
                }
            }
        }
        if item.title(for: .normal) == "象" {
            if position.0-2>=0 && position.1-2>=0 {
                if (redList.contains(where: { (pos) -> Bool in
                    return pos == (position.0-1,position.1-1)
                }) || (greenList.contains(where: { (pos) -> Bool in
                    return pos == (position.0-1,position.1-1)
                }))) {
                    //不添加此位置
                }else{
                    couldMovePositon.append((position.0-2,position.1-2))
                }
            }
            if position.0-2>=0 && position.1+2<=4 {
                if (redList.contains(where: { (pos) -> Bool in
                    return pos == (position.0-1,position.1+1)
                }) || (greenList.contains(where: { (pos) -> Bool in
                    return pos == (position.0-1,position.1+1)
                }))) {
                    //不添加此位置
                }else{
                    couldMovePositon.append((position.0-2,position.1+2))
                }
            }
            if position.0+2<=8 && position.1-2>=0 {
                if (redList.contains(where: { (pos) -> Bool in
                    return pos == (position.0+1,position.1-1)
                }) || (greenList.contains(where: { (pos) -> Bool in
                    return pos == (position.0+1,position.1-1)
                }))) {
                    //不添加此位置
                }else{
                    couldMovePositon.append((position.0+2,position.1-2))
                }
            }
            if position.0+2<=8 && position.1+2<=4 {
                if (redList.contains(where: { (pos) -> Bool in
                    return pos == (position.0+1,position.1+1)
                }) || (greenList.contains(where: { (pos) -> Bool in
                    return pos == (position.0+1,position.1+1)
                }))) {
                    //不添加此位置
                }else{
                    couldMovePositon.append((position.0+2,position.1+2))
                }
            }
        }
        if item.title(for: .normal) == "马" || item.title(for: .normal) == "馬" {
            if position.0-1>=0 && position.1-2>=0 {
                if (redList.contains(where: { (pos) -> Bool in
                    return pos == (position.0,position.1-1)
                })) || (greenList.contains(where: { (pos) -> Bool in
                    return pos == (position.0,position.1-1)
                })) {
                    
                }else{
                    couldMovePositon.append((position.0-1,position.1-2))
                }
            }
            
            if position.0+1<=8 && position.1-2>=0 {
                if (redList.contains(where: { (pos) -> Bool in
                    return pos == (position.0,position.1-1)
                })) || (greenList.contains(where: { (pos) -> Bool in
                    return pos == (position.0,position.1-1)
                })) {
                    
                }else{
                    couldMovePositon.append((position.0+1,position.1-2))
                }
            }
            if position.0+2<=8 && position.1-1>=0 {
                if (redList.contains(where: { (pos) -> Bool in
                    return pos == (position.0+1,position.1)
                })) || (greenList.contains(where: { (pos) -> Bool in
                    return pos == (position.0+1,position.1)
                })) {
                    
                }else{
                    couldMovePositon.append((position.0+2,position.1-1))
                }
            }
            if position.0+2<=8 && position.1+1<=9 {
                if (redList.contains(where: { (pos) -> Bool in
                    return pos == (position.0+1,position.1)
                })) || (greenList.contains(where: { (pos) -> Bool in
                    return pos == (position.0+1,position.1)
                })) {
                    
                }else{
                    couldMovePositon.append((position.0+2,position.1+1))
                }
            }
            if position.0+1<=8 && position.1+2<=9 {
                if (redList.contains(where: { (pos) -> Bool in
                    return pos == (position.0,position.1+1)
                })) || (greenList.contains(where: { (pos) -> Bool in
                    return pos == (position.0,position.1+1)
                })) {
                    
                }else{
                    couldMovePositon.append((position.0+1,position.1+2))
                }
            }
            if position.0-1>=0 && position.1+2<=9 {
                if (redList.contains(where: { (pos) -> Bool in
                    return pos == (position.0,position.1+1)
                })) || (greenList.contains(where: { (pos) -> Bool in
                    return pos == (position.0,position.1+1)
                })) {
                    
                }else{
                    couldMovePositon.append((position.0-1,position.1+2))
                }
            }
            if position.0-2>=0 && position.1+1<=9 {
                if (redList.contains(where: { (pos) -> Bool in
                    return pos == (position.0-1,position.1)
                })) || (greenList.contains(where: { (pos) -> Bool in
                    return pos == (position.0-1,position.1)
                })) {
                    
                }else{
                    couldMovePositon.append((position.0-2,position.1+1))
                }
            }
            if position.0-2>=0 && position.1-1>=0 {
                if (redList.contains(where: { (pos) -> Bool in
                    return pos == (position.0-1,position.1)
                })) || (greenList.contains(where: { (pos) -> Bool in
                    return pos == (position.0-1,position.1)
                })) {
                    
                }else{
                    couldMovePositon.append((position.0-2,position.1-1))
                }
            }
        }
        if item.title(for: .normal) == "车" || item.title(for: .normal) == "車" {
            var tmpP = position
            while tmpP.0-1>=0 {
                if (redList.contains(where: { (pos) -> Bool in
                    return pos == (tmpP.0-1,tmpP.1)
                })) ||  (greenList.contains(where: { (pos) -> Bool in
                    return pos == (tmpP.0-1,tmpP.1)
                }))  {
                    couldMovePositon.append((tmpP.0-1,tmpP.1))
                    break
                }else{
                    couldMovePositon.append((tmpP.0-1,tmpP.1))
                }
                tmpP.0-=1
            }
            tmpP = position
            while tmpP.0+1<=8 {
                if (redList.contains(where: { (pos) -> Bool in
                    return pos == (tmpP.0+1,tmpP.1)
                })) ||  (greenList.contains(where: { (pos) -> Bool in
                    return pos == (tmpP.0+1,tmpP.1)
                }))  {
                    couldMovePositon.append((tmpP.0+1,tmpP.1))
                    break
                }else{
                    couldMovePositon.append((tmpP.0+1,tmpP.1))
                }
                tmpP.0+=1
            }
            tmpP = position
            while tmpP.1-1>=0 {
                if (redList.contains(where: { (pos) -> Bool in
                    return pos == (tmpP.0,tmpP.1-1)
                })) ||  (greenList.contains(where: { (pos) -> Bool in
                    return pos == (tmpP.0,tmpP.1-1)
                }))  {
                    couldMovePositon.append((tmpP.0,tmpP.1-1))
                    break
                }else{
                    couldMovePositon.append((tmpP.0,tmpP.1-1))
                }
                tmpP.1-=1
            }
            tmpP = position
            while tmpP.1+1<=9 {
                if (redList.contains(where: { (pos) -> Bool in
                    return pos == (tmpP.0,tmpP.1+1)
                })) ||  (greenList.contains(where: { (pos) -> Bool in
                    return pos == (tmpP.0,tmpP.1+1)
                }))  {
                    couldMovePositon.append((tmpP.0,tmpP.1+1))
                    break
                }else{
                    couldMovePositon.append((tmpP.0,tmpP.1+1))
                }
                tmpP.1+=1
            }
        }
        if item.title(for: .normal) == "炮" {
            var tmpP = position
            var isFirst = true
            while tmpP.0-1>=0 {
                if (redList.contains(where: { (pos) -> Bool in
                    return pos == (tmpP.0-1,tmpP.1)
                })) ||  (greenList.contains(where: { (pos) -> Bool in
                    return pos == (tmpP.0-1,tmpP.1)
                }))  {
                    if isFirst {
                        isFirst = false
                    }else{
                        couldMovePositon.append((tmpP.0-1,tmpP.1))
                        break
                    }
                }else{
                    if isFirst {
                        couldMovePositon.append((tmpP.0-1,tmpP.1))
                    }
                }
                tmpP.0-=1
            }
            tmpP = position
            isFirst = true
            while tmpP.0+1<=8 {
                if (redList.contains(where: { (pos) -> Bool in
                    return pos == (tmpP.0+1,tmpP.1)
                })) ||  (greenList.contains(where: { (pos) -> Bool in
                    return pos == (tmpP.0+1,tmpP.1)
                }))  {
                    if isFirst {
                        isFirst = false
                    }else{
                        couldMovePositon.append((tmpP.0+1,tmpP.1))
                        break
                    }
                }else{
                    if isFirst {
                        couldMovePositon.append((tmpP.0+1,tmpP.1))
                    }
                }
                tmpP.0+=1
            }
            tmpP = position
            isFirst = true
            while tmpP.1-1>=0 {
                if (redList.contains(where: { (pos) -> Bool in
                    return pos == (tmpP.0,tmpP.1-1)
                })) ||  (greenList.contains(where: { (pos) -> Bool in
                    return pos == (tmpP.0,tmpP.1-1)
                }))  {
                    if isFirst {
                        isFirst = false
                    }else{
                        couldMovePositon.append((tmpP.0,tmpP.1-1))
                        break
                    }
                }else{
                    if isFirst {
                        couldMovePositon.append((tmpP.0,tmpP.1-1))
                    }
                }
                tmpP.1-=1
            }
            
            tmpP = position
            isFirst = true
            while tmpP.1+1<=9 {
                if (redList.contains(where: { (pos) -> Bool in
                    return pos == (tmpP.0,tmpP.1+1)
                })) ||  (greenList.contains(where: { (pos) -> Bool in
                    return pos == (tmpP.0,tmpP.1+1)
                }))  {
                    if isFirst {
                        isFirst = false
                    }else{
                        couldMovePositon.append((tmpP.0,tmpP.1+1))
                        break
                    }
                }else{
                    if isFirst {
                        couldMovePositon.append((tmpP.0,tmpP.1+1))
                    }
                }
                tmpP.1+=1
            }
        }
        gameBoard?.wantMove(positions: couldMovePositon, item: item)
    }
    
    func gameOver(redWin:Bool){
        isStarting = false
        if delegate != nil {
            delegate?.gameOver(redWin: redWin)
        }
    }
    
    func itemMoveEnd() {
        currentShouldRedMovde = !currentShouldRedMovde
        if delegate != nil {
            delegate?.couldMoveChange(red: currentShouldRedMovde)
        }
    }
}
