//
//  MusicEngine.swift
//  CheseChessGame
//
//  Created by vip on 16/11/17.
//  Copyright © 2016年 jaki. All rights reserved.
//

import UIKit
import AVFoundation
class MusicEngine: NSObject {
    static let sharedInstance = MusicEngine()
    var player:AVAudioPlayer?
    private override init() {
        let path = Bundle.main.path(forResource: "bgMusic", ofType: "mp3")
        let url = URL(fileURLWithPath: path!)
        let data = try! Data(contentsOf: url)
        player = try! AVAudioPlayer(data: data)
        player?.prepareToPlay()
    }
    
    func playBackgroudMusic()  {
        if !player!.isPlaying {
            player!.play()
        }
    }
    
    func stopBackgroudMusic() {
        if player!.isPlaying{
            player!.stop()
        }
    }
    
    
    
}
